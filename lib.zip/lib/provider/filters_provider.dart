import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:meals/provider/meals_provider.dart';
import '';

class FilterMealNotifier extends StateNotifier<List<bool>>{
  FilterMealNotifier(): super([false,false,false,false]);
  void changeSelection(bool isChecked,int index){
    final newState=List<bool>.from(state);
    newState[index]=isChecked;
    state=newState;
  }
}

final filterMealProvider=StateNotifierProvider<FilterMealNotifier,List<bool>>((ref){
  return FilterMealNotifier();
});

final filteredMealsProvider = Provider((ref) {
  final meals = ref.watch(mealsProvider);
  final activeFilters = ref.watch(filterMealProvider);

  return meals.where((meal) {
    if (activeFilters[0] && !meal.isGlutenFree) {
      return false;
    }
    if (activeFilters[1] && !meal.isLactoseFree) {
      return false;
    }
    if (activeFilters[2] && !meal.isVegetarian) {
      return false;
    }
    if (activeFilters[3] && !meal.isVegan) {
      return false;
    }
    return true;
  }).toList();
});