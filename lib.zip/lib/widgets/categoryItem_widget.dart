import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:meals/models/meals.dart';
import 'package:transparent_image/transparent_image.dart';
import 'package:meals/widgets/categoryItemData_widget.dart';

class CategoryItemWidget extends StatelessWidget {
  const CategoryItemWidget({super.key, required this.categoryItem,required this.aboutItem});
  final void Function(Meal item) aboutItem;
  String textEnum(int n){
    if(n==1){
      return categoryItem.complexity.name[0].toUpperCase()+categoryItem.complexity.name.substring(1);
    }
    return categoryItem.affordability.name[0].toUpperCase()+categoryItem.affordability.name.substring(1);
  }

  final Meal categoryItem;
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      elevation: 2,
      shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(8)),
      clipBehavior:Clip.hardEdge,
      child: InkWell(
        onTap: () {aboutItem(categoryItem);},
        child: Stack(
          children: [
            Hero(
              tag:categoryItem.id,
              child: FadeInImage(
                fit: BoxFit.cover,
                  height: 200,
                  width: double.infinity,
                  placeholder: MemoryImage(kTransparentImage),
                  image: NetworkImage(categoryItem.imageUrl)),
            ),
            Positioned(
                bottom: 0,
                right: 0,
                left: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 44,vertical: 6),
                  color: Colors.black54,
                  child: Column(
                      children: [
                    Text(
                      categoryItem.title,
                      maxLines: 2,
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        CategoryItemDataWidget(data: '${categoryItem.duration} min', icon: Icons.access_time),
                        CategoryItemDataWidget(data: textEnum(1), icon: Icons.work),
                        CategoryItemDataWidget(data: textEnum(0), icon: Icons.currency_rupee),
                      ],
                    )
                  ]),
                ))
          ],
        ),
      ),
    );
  }
}
