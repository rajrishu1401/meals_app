import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CategoryItemDataWidget extends StatelessWidget{
  const CategoryItemDataWidget({super.key,required this.data,required this.icon});
  final String data;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon),
        const SizedBox(
          width: 5,
        ),
        Text(data,style: const TextStyle(color: Colors.white,fontSize: 15),)
      ],
    );
  }
}