import 'package:flutter/material.dart';
import 'package:meals/models/category.dart';

class CategoryWidget extends StatelessWidget{
  const CategoryWidget({super.key,required this.category,required this.categoryInside});
  final void Function(Category) categoryInside;
  final Category category;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){categoryInside(category);},
      borderRadius: BorderRadius.circular(15),
      splashColor: Theme.of(context).colorScheme.primaryContainer,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              category.color.withOpacity(0.55),
              category.color.withOpacity(0.9)
            ]
          ),
            borderRadius: BorderRadius.circular(15)
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(category.title,style: Theme.of(context).textTheme.labelLarge!.copyWith(
            color: Colors.white,
          ),),
        ),
      ),
    );
  }
}