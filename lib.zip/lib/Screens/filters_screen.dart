import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:meals/provider/filters_provider.dart';

class FiltersScreen extends ConsumerWidget{
  const FiltersScreen({super.key});
  @override
  Widget build(BuildContext context,WidgetRef ref) {
    final selectedFilter=ref.watch(filterMealProvider);
    Widget filterWidget(String title,String subtitle,int index){
      return SwitchListTile(value:selectedFilter[index], onChanged:(isChecked){
        ref.read(filterMealProvider.notifier).changeSelection(isChecked, index);
      },
        title: Text(title,style: Theme.of(context).textTheme.titleLarge!.copyWith(
          color: Theme.of(context).colorScheme.onBackground,
        ),),
        subtitle: Text(subtitle,style: Theme.of(context).textTheme.labelMedium!.copyWith(
          color: Theme.of(context).colorScheme.onBackground,
        ),),
        activeColor:Theme.of(context).colorScheme.tertiary ,
        contentPadding: const EdgeInsets.only(right: 22,left: 34,),
      );
    }
    return Scaffold(
        appBar: AppBar(
          title:const Text('Your Filter'),
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        ),
        body: Column(
          children: [
            filterWidget('Gluten-Free','Only include gluten-free meals.',0),
            filterWidget('Lactose-Free','Only include lactose-free meals.',1),
            filterWidget('Vegetarian','Only include vegetarian meals.',2),
            filterWidget('Vegan','Only include vegan meals.',3),
          ],
        )
    );
  }
}