import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:meals/models/meals.dart';
import 'package:meals/provider/favorites_provider.dart';
import 'package:transparent_image/transparent_image.dart';

class AboutItemScreen extends ConsumerWidget{
  const AboutItemScreen({super.key,required this.item});
  final Meal item;
  @override
  Widget build(BuildContext context,WidgetRef ref) {
    final isFavoriteMeal=ref.watch(favoritesMealProvider).contains(item);
    void showMessage(String message) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: Theme.of(context).textTheme.bodyLarge!.copyWith(
              color: Colors.blue,
            ),
          ),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed:(){
              final isAdded=ref.read(favoritesMealProvider.notifier).toggleMealFavorite(item);
              if(isAdded){
                showMessage('Meal added to favorites!');
              }
              else{
                showMessage('Meal removed from favorites!');
              }
            },
              icon: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, animation){
                    return RotationTransition(
                      turns:Tween(begin: 0.8,end: 1.0).animate(animation),
                      child: child,);
                  },
                  child: Icon(isFavoriteMeal?Icons.star:Icons.star_outline,key:ValueKey(isFavoriteMeal),)),)
        ],
        title:Text(item.title),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: ListView(
        children: [
          Hero(
            tag: item.id,
            child: FadeInImage(
              placeholder:MemoryImage(kTransparentImage) ,
                image: NetworkImage(item.imageUrl)),
          ),
          const SizedBox(
            height: 10,
          ),
          Text('Ingredients',style:Theme.of(context).textTheme.titleLarge!.copyWith(color: Colors.orangeAccent),textAlign: TextAlign.center,),
          const SizedBox(
            height: 10,
          ),
          for (final str in item.ingredients)
            Text(str,style:Theme.of(context).textTheme.labelLarge!.copyWith(color: Colors.white),textAlign: TextAlign.center,),
          const SizedBox(
            height: 20,
          ),
          Text('Steps',style:Theme.of(context).textTheme.titleLarge!.copyWith(color: Colors.orangeAccent),textAlign: TextAlign.center,),
          const SizedBox(
            height: 10,
          ),
          ...item.steps.map((step) => Padding(
            padding: const EdgeInsets.all(6),
            child: Text(step,style:Theme.of(context).textTheme.labelLarge!.copyWith(color: Colors.white),textAlign: TextAlign.center,),
          )),
        ],
      ),
    );
  }
}