import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:meals/Screens/Category_Screen.dart';
import 'package:meals/Screens/categoryItem_Screen.dart';
import 'package:meals/Screens/filters_screen.dart';
import 'package:meals/provider/favorites_provider.dart';
import 'package:meals/widgets/drawer_widget.dart';

class TabScreen extends ConsumerStatefulWidget {
  const TabScreen({super.key});

  @override
  ConsumerState<TabScreen> createState() {
    return _TabScreen();
  }
}

class _TabScreen extends ConsumerState<TabScreen> {

  void _drawerScreenChange(String screen){
    Navigator.pop(context);
    if(screen=='Filters'){
      Navigator.push(context, MaterialPageRoute(builder:(ctx)=>const FiltersScreen(),));
    }
  }

  int selectedTabIndex = 0;
  void selectTab(int index) {
    setState(() {
      if (index == 1) {
        selectedTabIndex = 1;
      } else {
        selectedTabIndex = 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget activeScreen = const CategoryScreen();
    String activeTitle = 'Choose a Category';
    if (selectedTabIndex == 1) {
      final favoriteMeal=ref.watch(favoritesMealProvider);
      activeScreen = CategoryItemScreen(
        categoryItem: favoriteMeal,
      );
      activeTitle = 'Your Favorites';
    }
    return Scaffold(
      drawer: DrawerWidget(changeScreen: _drawerScreenChange,),
      appBar: AppBar(
        title: Text(activeTitle),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: activeScreen,
      bottomNavigationBar: BottomNavigationBar(
        onTap: selectTab,
        currentIndex: selectedTabIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.set_meal),
            label: 'Categories',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Favorites',
          )
        ],
      ),
    );
  }
}
